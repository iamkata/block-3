//
//  main.m
//  Interview01-__block
//
//  Created by MJ Lee on 2018/5/15.
//  Copyright © 2018年 MJ Lee. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MJPerson.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // MRC不支持__weak的否则报错：👇
        // Cannot create __weak reference in file using manual reference counting
        
//        __block MJPerson *person = [[MJPerson alloc] init];
//
//        person.age = 10;
//        person.block = [^{
//            NSLog(@"age is %d", person.age);
//        } copy];
//        
//        [person release];
        
        
//        __weak MJPerson *weakPerson = person;
        
        
        // __weak：不会产生强引用，指向的对象销毁时，会自动让指针置为nil
        // __unsafe_unretained：不会产生强引用，不安全，指向的对象销毁时，指针存储的地址值不变
        
        MJPerson *person = [[MJPerson alloc] init];
        __weak typeof(person) weakPerson = person;

        person.block = ^{
            __strong typeof(weakPerson) strongPerson = weakPerson;
            
            NSLog(@"age is %d", strongPerson.age);
        };
        
        //使用__block解决循环引用
//        MJPerson *person = [[MJPerson alloc] init];
//
//        __block typeof(person) weakPerson = person;
//        person.age = 10;
//        person.block = ^{
//            NSLog(@"age is %d", weakPerson.age);
//            weakPerson = nil;
//        };
//
//        person.block();
    }
    
    NSLog(@"111111111111");
    return 0;
}
